enum WeightUnit {
  kilograms,
  pounds,
}